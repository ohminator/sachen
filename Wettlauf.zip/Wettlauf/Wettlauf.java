public class Wettlauf {
    
    private Laeufer[] laeuferfeld;
    private int anzahlBahnen;
    private int anzahlLaeufer;
    private boolean[] laufbahnBelegt;

    
    public Wettlauf(int pAnzahlBahnen) {
        this.anzahlBahnen = pAnzahlBahnen;
        this.laeuferfeld = new Laeufer[pAnzahlBahnen];
        this.laufbahnBelegt = new boolean[pAnzahlBahnen];
        this.anzahlLaeufer = 0;
    }

    
    public void anDenStart(int pBahn, Laeufer pLaeufer) {
        if (pBahn >= 0 && pBahn < anzahlBahnen && !laufbahnBelegt[pBahn]) {
            laeuferfeld[pBahn] = pLaeufer;
            laufbahnBelegt[pBahn] = true;
            anzahlLaeufer++;
        } else {
            System.out.println("Bahn " + pBahn + " ist bereits belegt oder ungültig!");
        }
    }

    
    public boolean bahnBelegt(int pBahn) {
        if (pBahn >= 0 && pBahn < anzahlBahnen) {
            return laufbahnBelegt[pBahn];
        }
        return false;
    }

    
    public double zeitMessen() {
        double besteZeit = Double.MAX_VALUE;
        for (Laeufer l : laeuferfeld) {
            if (l != null && l.getZeit() < besteZeit) {
                besteZeit = l.getZeit();
            }
        }
        return besteZeit;
    }

    
    public void rennenLaufen() {
        for (Laeufer l : laeuferfeld) {
            if (l != null) {
                double zufallsZeit = 10 + Math.random() * 5; 
                l.setZeit(zufallsZeit);
                l.setQuali(zufallsZeit <= 12.0);
            }
        }
    }
}
