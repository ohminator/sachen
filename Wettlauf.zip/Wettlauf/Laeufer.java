public class Laeufer {
    
    private String name;
    private double zeit;
    private boolean quali;

    public Laeufer(String pName) {
        this.name = pName;
        this.zeit = 0.0;
        this.quali = false;
    }

    public double getZeit() {
        return zeit;
    }

    public void setZeit(double pZeit) {
        this.zeit = pZeit;
    }

    public String getName() {
        return name;
    }

    public boolean getQuali() {
        return quali;
    }

    public void setQuali(boolean pQuali) {
        this.quali = pQuali;
    }
}
